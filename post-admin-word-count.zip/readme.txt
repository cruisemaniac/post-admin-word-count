=== Plugin Name ===
Contributors: Post Admin Word Count
Donate link: http://www.jonbishop.com/donate/
Tags: wordcount, word count, words, count, column, admin, sortable, posts
Requires at least: 1.0
Tested up to: 3.0
Stable tag: 1.0

Adds a sortable column to the admin's post manager, displaying the word count for each post.

== Description ==

Post Word Count adds a sortable column to the admin's post manager, displaying the word count for each post.

== Installation ==

1. Upload the 'post-word-count' folder to the '/wp-content/plugins/' directory
1. Activate the plugin through the 'Plugins' menu in WordPresss

== Changelog ==

= 1.0 =
* First version